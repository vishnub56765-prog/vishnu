-- ==============================================================================
-- ALVIYA DAIRY - Row Level Security (RLS) Policies
-- Main Owner -> Access to all centers
-- Center Owner -> Access STRICTLY to their own center
-- ==============================================================================

-- 1. Enable RLS on all tables
ALTER TABLE public.company_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.centers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.milk_collections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.advances ENABLE ROW LEVEL SECURITY;

-- 2. Helper Functions for Role Resolution
CREATE OR REPLACE FUNCTION public.is_main_owner()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN (
        auth.jwt() ->> 'email' = 'vishnub56765@gmail.com' OR
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'owner'
        )
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.get_auth_center_id()
RETURNS UUID AS $$
BEGIN
    RETURN (
        SELECT center_id FROM public.profiles
        WHERE id = auth.uid() AND role = 'center'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ------------------------------------------------------------------------------
-- Company Settings Policies
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Anyone authenticated can view settings" ON public.company_settings;
CREATE POLICY "Anyone authenticated can view settings"
    ON public.company_settings FOR SELECT
    TO authenticated
    USING (true);

DROP POLICY IF EXISTS "Main Owner can modify settings" ON public.company_settings;
CREATE POLICY "Main Owner can modify settings"
    ON public.company_settings FOR ALL
    TO authenticated
    USING (public.is_main_owner())
    WITH CHECK (public.is_main_owner());

-- ------------------------------------------------------------------------------
-- Centers Policies
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Main Owner has full access to centers" ON public.centers;
CREATE POLICY "Main Owner has full access to centers"
    ON public.centers FOR ALL
    TO authenticated
    USING (public.is_main_owner())
    WITH CHECK (public.is_main_owner());

DROP POLICY IF EXISTS "Center Owner can view their own center" ON public.centers;
CREATE POLICY "Center Owner can view their own center"
    ON public.centers FOR SELECT
    TO authenticated
    USING (id = public.get_auth_center_id());

-- ------------------------------------------------------------------------------
-- Profiles Policies
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Users can read own profile" ON public.profiles;
CREATE POLICY "Users can read own profile"
    ON public.profiles FOR SELECT
    TO authenticated
    USING (id = auth.uid() OR public.is_main_owner());

-- ------------------------------------------------------------------------------
-- Farmers Policies
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Main Owner has full access to farmers" ON public.farmers;
CREATE POLICY "Main Owner has full access to farmers"
    ON public.farmers FOR ALL
    TO authenticated
    USING (public.is_main_owner())
    WITH CHECK (public.is_main_owner());

DROP POLICY IF EXISTS "Center Owner can view their center farmers" ON public.farmers;
CREATE POLICY "Center Owner can view their center farmers"
    ON public.farmers FOR SELECT
    TO authenticated
    USING (center_id = public.get_auth_center_id());

DROP POLICY IF EXISTS "Center Owner can insert farmers to their center" ON public.farmers;
CREATE POLICY "Center Owner can insert farmers to their center"
    ON public.farmers FOR INSERT
    TO authenticated
    WITH CHECK (center_id = public.get_auth_center_id());

DROP POLICY IF EXISTS "Center Owner can update their center farmers" ON public.farmers;
CREATE POLICY "Center Owner can update their center farmers"
    ON public.farmers FOR UPDATE
    TO authenticated
    USING (center_id = public.get_auth_center_id())
    WITH CHECK (center_id = public.get_auth_center_id());

-- ------------------------------------------------------------------------------
-- Milk Collections Policies
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Main Owner has full access to collections" ON public.milk_collections;
CREATE POLICY "Main Owner has full access to collections"
    ON public.milk_collections FOR ALL
    TO authenticated
    USING (public.is_main_owner())
    WITH CHECK (public.is_main_owner());

DROP POLICY IF EXISTS "Center Owner can view their center collections" ON public.milk_collections;
CREATE POLICY "Center Owner can view their center collections"
    ON public.milk_collections FOR SELECT
    TO authenticated
    USING (center_id = public.get_auth_center_id());

DROP POLICY IF EXISTS "Center Owner can insert collections for their center" ON public.milk_collections;
CREATE POLICY "Center Owner can insert collections for their center"
    ON public.milk_collections FOR INSERT
    TO authenticated
    WITH CHECK (center_id = public.get_auth_center_id());

-- ------------------------------------------------------------------------------
-- Advances Policies
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Main Owner has full access to advances" ON public.advances;
CREATE POLICY "Main Owner has full access to advances"
    ON public.advances FOR ALL
    TO authenticated
    USING (public.is_main_owner())
    WITH CHECK (public.is_main_owner());

DROP POLICY IF EXISTS "Center Owner can view advances for their center (read-only)" ON public.advances;
CREATE POLICY "Center Owner can view advances for their center (read-only)"
    ON public.advances FOR SELECT
    TO authenticated
    USING (center_id = public.get_auth_center_id());
