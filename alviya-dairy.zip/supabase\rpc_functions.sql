-- ==============================================================================
-- ALVIYA DAIRY - Secure PostgreSQL RPC Functions
-- Enables Main Owner to securely manage Center Owner credentials in auth.users
-- ==============================================================================

-- 1. Create Center with working Supabase Auth credentials
CREATE OR REPLACE FUNCTION public.create_center_account(
    p_name TEXT,
    p_code TEXT,
    p_password TEXT,
    p_recovery_code TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, extensions
AS $$
DECLARE
    v_clean_code TEXT;
    v_email TEXT;
    v_user_id UUID;
    v_center_id UUID;
    v_encrypted_pw TEXT;
BEGIN
    -- Only Main Owner can create center accounts
    IF NOT public.is_main_owner() THEN
        RAISE EXCEPTION 'Unauthorized: Only Main Owner can create centers.';
    END IF;

    v_clean_code := UPPER(TRIM(p_code));
    v_email := LOWER(v_clean_code) || '@centers.alviyadairy.local';
    v_user_id := gen_random_uuid();
    v_center_id := gen_random_uuid();
    v_encrypted_pw := crypt(p_password, gen_salt('bf'));

    -- 1. Create auth user in Supabase auth schema
    INSERT INTO auth.users (
        id,
        instance_id,
        email,
        encrypted_password,
        email_confirmed_at,
        created_at,
        updated_at,
        raw_app_meta_data,
        raw_user_meta_data,
        is_super_admin,
        role
    ) VALUES (
        v_user_id,
        '00000000-0000-0000-0000-000000000000',
        v_email,
        v_encrypted_pw,
        NOW(),
        NOW(),
        NOW(),
        jsonb_build_object('provider', 'email', 'providers', array['email']),
        jsonb_build_object('center_code', v_clean_code, 'name', p_name),
        FALSE,
        'authenticated'
    );

    -- 2. Create Center in public.centers
    INSERT INTO public.centers (
        id,
        name,
        code,
        recovery_code,
        user_id,
        created_at,
        updated_at
    ) VALUES (
        v_center_id,
        p_name,
        v_clean_code,
        p_recovery_code,
        v_user_id,
        NOW(),
        NOW()
    );

    -- 3. Create Profile in public.profiles
    INSERT INTO public.profiles (
        id,
        email,
        role,
        center_id,
        login_id,
        created_at
    ) VALUES (
        v_user_id,
        v_email,
        'center',
        v_center_id,
        v_clean_code,
        NOW()
    );

    RETURN jsonb_build_object(
        'success', true,
        'center_id', v_center_id,
        'user_id', v_user_id,
        'code', v_clean_code
    );
END;
$$;

-- 2. Update Center name, code, or password
CREATE OR REPLACE FUNCTION public.update_center_account(
    p_center_id UUID,
    p_name TEXT,
    p_code TEXT,
    p_password TEXT DEFAULT NULL,
    p_recovery_code TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, extensions
AS $$
DECLARE
    v_clean_code TEXT;
    v_email TEXT;
    v_user_id UUID;
BEGIN
    IF NOT public.is_main_owner() THEN
        RAISE EXCEPTION 'Unauthorized: Only Main Owner can modify centers.';
    END IF;

    v_clean_code := UPPER(TRIM(p_code));
    v_email := LOWER(v_clean_code) || '@centers.alviyadairy.local';

    SELECT user_id INTO v_user_id FROM public.centers WHERE id = p_center_id;

    -- Update Center info
    UPDATE public.centers
    SET name = p_name,
        code = v_clean_code,
        recovery_code = COALESCE(p_recovery_code, recovery_code),
        updated_at = NOW()
    WHERE id = p_center_id;

    -- Update Auth credentials if password provided
    IF v_user_id IS NOT NULL THEN
        UPDATE public.profiles
        SET email = v_email,
            login_id = v_clean_code
        WHERE id = v_user_id;

        IF p_password IS NOT NULL AND length(p_password) >= 6 THEN
            UPDATE auth.users
            SET email = v_email,
                encrypted_password = crypt(p_password, gen_salt('bf')),
                updated_at = NOW()
            WHERE id = v_user_id;
        ELSE
            UPDATE auth.users
            SET email = v_email,
                updated_at = NOW()
            WHERE id = v_user_id;
        END IF;
    END IF;

    RETURN jsonb_build_object('success', true);
END;
$$;

-- 3. Delete Center and associated auth user
CREATE OR REPLACE FUNCTION public.delete_center_account(
    p_center_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, extensions
AS $$
DECLARE
    v_user_id UUID;
BEGIN
    IF NOT public.is_main_owner() THEN
        RAISE EXCEPTION 'Unauthorized: Only Main Owner can delete centers.';
    END IF;

    SELECT user_id INTO v_user_id FROM public.centers WHERE id = p_center_id;

    -- Delete center (cascades to farmers, collections, advances)
    DELETE FROM public.centers WHERE id = p_center_id;

    -- Delete auth user
    IF v_user_id IS NOT NULL THEN
        DELETE FROM auth.users WHERE id = v_user_id;
    END IF;

    RETURN jsonb_build_object('success', true);
END;
$$;
