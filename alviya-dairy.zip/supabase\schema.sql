-- ==============================================================================
-- ALVIYA DAIRY - Production PostgreSQL Normalized Schema
-- ==============================================================================

-- 1. Enable UUID generator extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Company Settings Table (Global TS Rate Multiplier)
CREATE TABLE IF NOT EXISTS public.company_settings (
    id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    ts NUMERIC(6, 2) NOT NULL DEFAULT 2.80,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Centers Table
CREATE TABLE IF NOT EXISTS public.centers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    code TEXT NOT NULL UNIQUE,
    recovery_code TEXT,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. User Profiles Table (Role Authorization & Center Mapping)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('owner', 'center')),
    center_id UUID REFERENCES public.centers(id) ON DELETE CASCADE,
    login_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Farmers Table (Belongs to Center)
CREATE TABLE IF NOT EXISTS public.farmers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    center_id UUID NOT NULL REFERENCES public.centers(id) ON DELETE CASCADE,
    milk_no TEXT NOT NULL,
    name TEXT NOT NULL,
    bank_holder TEXT DEFAULT '',
    bank_name TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    bank_ifsc TEXT DEFAULT '',
    bank_branch TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_farmer_per_center UNIQUE (center_id, milk_no)
);

-- 6. Milk Collections Table (Belongs to Center & Farmer)
CREATE TABLE IF NOT EXISTS public.milk_collections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    center_id UUID NOT NULL REFERENCES public.centers(id) ON DELETE CASCADE,
    farmer_id UUID NOT NULL REFERENCES public.farmers(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    session TEXT NOT NULL CHECK (session IN ('Morning', 'Evening')),
    liters NUMERIC(10, 2) NOT NULL CHECK (liters > 0),
    fat NUMERIC(5, 2) NOT NULL CHECK (fat >= 0),
    snf NUMERIC(5, 2) NOT NULL CHECK (snf >= 0),
    ts NUMERIC(6, 2) NOT NULL CHECK (ts > 0), -- Frozen TS rate multiplier used at collection time
    rate NUMERIC(10, 2) NOT NULL,
    amount NUMERIC(12, 2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_collection_session UNIQUE (center_id, farmer_id, date, session)
);

-- 7. Advances Table (Belongs to Center & Farmer)
CREATE TABLE IF NOT EXISTS public.advances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    center_id UUID NOT NULL REFERENCES public.centers(id) ON DELETE CASCADE,
    farmer_id UUID NOT NULL REFERENCES public.farmers(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    note TEXT DEFAULT '',
    created_by TEXT DEFAULT 'Main Owner',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- Indexes for High Performance Queries (Billing, Reports, and Filtering)
-- ==============================================================================
CREATE INDEX IF NOT EXISTS idx_farmers_center ON public.farmers(center_id);
CREATE INDEX IF NOT EXISTS idx_collections_center_date ON public.milk_collections(center_id, date);
CREATE INDEX IF NOT EXISTS idx_collections_farmer_date ON public.milk_collections(farmer_id, date);
CREATE INDEX IF NOT EXISTS idx_advances_center_date ON public.advances(center_id, date);
CREATE INDEX IF NOT EXISTS idx_advances_farmer_date ON public.advances(farmer_id, date);
