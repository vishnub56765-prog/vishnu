-- ==============================================================================
-- ALVIYA DAIRY - Initial Seed Data
-- ==============================================================================

-- 1. Initialize Company Settings with Default TS
INSERT INTO public.company_settings (id, ts, updated_at)
VALUES (1, 2.80, NOW())
ON CONFLICT (id) DO UPDATE SET ts = 2.80;

-- 2. Trigger to automatically link Main Owner profile on sign-up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.email = 'vishnub56765@gmail.com' THEN
        INSERT INTO public.profiles (id, email, role, center_id, login_id)
        VALUES (NEW.id, NEW.email, 'owner', NULL, 'ALVIYA-MAIN')
        ON CONFLICT (id) DO UPDATE
        SET role = 'owner', login_id = 'ALVIYA-MAIN';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Also ensure existing user is promoted to owner if already signed up
INSERT INTO public.profiles (id, email, role, center_id, login_id)
SELECT id, email, 'owner', NULL, 'ALVIYA-MAIN'
FROM auth.users
WHERE email = 'vishnub56765@gmail.com'
ON CONFLICT (id) DO UPDATE
SET role = 'owner', login_id = 'ALVIYA-MAIN';
